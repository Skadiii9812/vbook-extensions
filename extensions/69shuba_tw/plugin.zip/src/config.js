var BASE_URL = "https://69shuba.tw";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (e) {}

// ============ Asset Blocking Lists ============
// _BLOCK_ADS: ad networks confirmed from 69shuba_tw device testing.
// cn.macacusdame.com confirmed in chap.js device output. Add more as discovered.
var _BLOCK_ADS = [
    "cn.macacusdame.com",
    "googletagmanager",
    "google-analytics",
    "cloudflareinsights"
];

// _BLOCK_HEAVY: generic static assets — not needed for HTML content parsing.
// Blocking these speeds up all browser sessions significantly.
var _BLOCK_HEAVY = [
    ".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg",
    ".css", ".woff", ".woff2", ".ttf", ".eot"
];

// ============ Cloudflare Cookie System ============
var _cfCookie = null;
var _cfUA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
var _cfReady = false;
var _HOMEPAGE_URL = BASE_URL + "/";
var _CF_COOKIE_KEY = "69sh_cf";
var _CF_COOKIE_TS_KEY = "69sh_cf_ts";
var _CF_PROBE_TS_KEY = "69sh_cf_probe_ts";
var _CF_COOKIE_MAX_AGE_MS = 48 * 60 * 60 * 1000;
var _CF_PROBE_MAX_AGE_MS = 10 * 60 * 1000;
var _DETAIL_SYNC_PREFIX = "69sh_detail_sync_ts_";
var _DETAIL_SYNC_TTL_MS = 5 * 60 * 1000;

function isCfChallengeText(t) {
    t = (t || "") + "";
    if (t.length < 200) return true;
    if (t.indexOf("Just a moment") >= 0) return true;
    if (t.indexOf("Please complete human verification") >= 0) return true;
    if (t.indexOf("Verify you are human") >= 0) return true;
    return false;
}

function isValid69shDoc(doc, url) {
    if (!doc) return false;
    var t = doc.text() + "";
    if (isCfChallengeText(t)) return false;
    url = (url || "") + "";
    if (url.indexOf("/indexlist/") >= 0) return isValidIndexDoc(doc);
    if (url.indexOf("/book/") >= 0) {
        var metaTitle = doc.select('meta[property="og:title"]').attr("content") + "";
        return metaTitle.length > 0 || t.indexOf("69\u66f8\u5427") >= 0;
    }
    if (url.indexOf("/txt/") >= 0 || url.indexOf("/read/") >= 0) {
        return doc.select("#nr1").size() > 0 || t.length > 500;
    }
    if (url.indexOf("/search") >= 0) {
        return doc.select("table.list-item").size() > 0 || t.length > 500;
    }
    var title = doc.select("title").text() + "";
    return title.indexOf("69\u66f8\u5427") >= 0 || t.indexOf("69\u66f8\u5427") >= 0;
}

function isCookieStale() {
    try {
        var ts = parseInt(localStorage.getItem(_CF_COOKIE_TS_KEY) || "0", 10);
        if (!ts) return !loadCookie();
        return (Date.now() - ts) > _CF_COOKIE_MAX_AGE_MS;
    } catch (e) {}
    return false;
}

function markCfProbeOk() {
    _cfReady = true;
    try { localStorage.setItem(_CF_PROBE_TS_KEY, String(Date.now())); } catch (e) {}
}

function isCfProbeRecent() {
    try {
        var ts = parseInt(localStorage.getItem(_CF_PROBE_TS_KEY) || "0", 10);
        return ts > 0 && (Date.now() - ts) < _CF_PROBE_MAX_AGE_MS;
    } catch (e) {}
    return false;
}

function loadCookie() {
    if (_cfCookie) return _cfCookie;
    try {
        var lc = localCookie.getCookie() + "";
        if (lc && lc.length > 10) { _cfCookie = lc; return _cfCookie; }
    } catch (e) {}
    try {
        var ls = localStorage.getItem(_CF_COOKIE_KEY);
        if (ls && ls.length > 10) { _cfCookie = ls; return _cfCookie; }
    } catch (e) {}
    return null;
}

function storeCookie(cookie) {
    if (!cookie || cookie.length < 5) return;
    _cfCookie = cookie;
    _cfReady = true;
    try {
        localStorage.setItem(_CF_COOKIE_KEY, cookie);
        localStorage.setItem(_CF_COOKIE_TS_KEY, String(Date.now()));
    } catch (e) {}
    try {
        var parts = cookie.split(";");
        for (var i = 0; i < parts.length; i++) {
            var p = parts[i].trim();
            if (p) localCookie.setCookie(p);
        }
    } catch (e) {}
}

function invalidateCookie() {
    _cfCookie = null;
    _cfReady = false;
    try {
        localStorage.removeItem(_CF_COOKIE_KEY);
        localStorage.removeItem(_CF_COOKIE_TS_KEY);
        localStorage.removeItem(_CF_PROBE_TS_KEY);
    } catch (e) {}
}

function extractCookiesFromBrowser(browser) {
    var cookie = "";
    try {
        browser.callJs("window._69shc = document.cookie;", 300);
        cookie = browser.getVariable("_69shc") + "";
    } catch (e) {}
    if (!cookie || cookie.length < 10) {
        try { cookie = localCookie.getCookie() + ""; } catch (e) {}
    }
    if (cookie && cookie.length > 5) {
        storeCookie(cookie);
    }
}

function waitForCfBrowser(browser, maxMs) {
    var elapsed = 0;
    var step = 250;
    var limit = maxMs !== undefined ? maxMs : 20000;
    var doc = null;
    while (elapsed < limit) {
        try { doc = browser.html(); } catch (e) { doc = null; }
        if (doc) {
            var t = doc.text() + "";
            if (!isCfChallengeText(t) && (t.indexOf("69\u66f8\u5427") >= 0 || t.length > 800)) {
                return doc;
            }
        }
        sleep(step);
        elapsed += step;
    }
    try { return browser.html(); } catch (e2) {}
    return doc;
}

function probeCfSession() {
    if (isCookieStale()) {
        invalidateCookie();
        return false;
    }
    if (!loadCookie()) return false;
    var doc = fetchFast(_HOMEPAGE_URL, true);
    if (doc && isValid69shDoc(doc, _HOMEPAGE_URL)) {
        markCfProbeOk();
        Console.log("[69sh] probe ok");
        return true;
    }
    Console.log("[69sh] probe fail");
    return false;
}

function warmupCF() {
    if (probeCfSession()) return true;

    Console.log("[69sh] warmup browser");
    var browser = Engine.newBrowser();
    try {
        browser.setUserAgent(UserAgent.android());
        browser.block(_BLOCK_ADS.concat(_BLOCK_HEAVY));
        browser.launch(_HOMEPAGE_URL, 15000);
        waitForCfBrowser(browser, 20000);
        extractCookiesFromBrowser(browser);
    } finally {
        browser.close();
    }
    _cfReady = probeCfSession();
    return _cfReady;
}

function ensureCfReady() {
    if (isCookieStale()) invalidateCookie();
    if (probeCfSession()) return true;
    invalidateCookie();
    return warmupCF();
}

function fetchFast(url, skipInvalidate) {
    if (isCookieStale()) invalidateCookie();
    var cookie = loadCookie();
    if (!cookie) return null;
    try {
        var res = fetch(url, {
            headers: {
                "User-Agent": _cfUA,
                "Accept": "text/html",
                "Accept-Language": "zh-TW,zh;q=0.9",
                "Cookie": cookie
            }
        });
        if (res && res.ok) {
            var doc = res.html();
            if (doc && isValid69shDoc(doc, url)) {
                markCfProbeOk();
                return doc;
            }
        }
    } catch (e) {}
    if (!skipInvalidate) invalidateCookie();
    return null;
}

function fetchBrowserCF(url, timeout) {
    var t = timeout !== undefined ? timeout : 15000;
    var browser = Engine.newBrowser();
    var doc = null;
    try {
        browser.setUserAgent(UserAgent.android());
        browser.block(_BLOCK_ADS.concat(_BLOCK_HEAVY));
        browser.launch(url, t);
        doc = waitForCfBrowser(browser, 20000);
        if (doc && !isCfChallengeText(doc.text() + "")) {
            extractCookiesFromBrowser(browser);
            markCfProbeOk();
        } else {
            doc = null;
        }
    } finally {
        browser.close();
    }
    return doc;
}

function fetchCF(url) {
    url = (url || "").replace("http://", "https://");
    ensureCfReady();
    var doc = fetchFast(url);
    if (doc) return doc;
    doc = fetchBrowserCF(url);
    if (doc && isValid69shDoc(doc, url)) return doc;
    return null;
}

function canUseTocCache() {
    return isCfProbeRecent() || probeCfSession();
}

// ============ Throttled fetch (TOC pagination / burst calls) ============
// 1s gap between consecutive indexlist fetches — balances speed vs CF rate limits.
// page.js uses unthrottled fetchCF (single request). Only toc.js paces multi-page fetches.
var _FETCH_MIN_MS = 1000;
var _LAST_FETCH_KEY = "69sh_last_fetch";

function throttleWait() {
    var now = Date.now();
    var last = 0;
    try {
        last = parseInt(localStorage.getItem(_LAST_FETCH_KEY) || "0", 10);
    } catch (e) {}
    var gap = now - last;
    if (gap < _FETCH_MIN_MS) {
        sleep(_FETCH_MIN_MS - gap);
    }
}

function markFetch() {
    try {
        localStorage.setItem(_LAST_FETCH_KEY, String(Date.now()));
    } catch (e) {}
}

function fetchCFThrottled(url) {
    throttleWait();
    var doc = fetchCF(url);
    markFetch();
    return doc;
}

// ============ Indexlist URL + parsing helpers ============
function resolveIndexUrl(url) {
    url = (url || "").replace("http://", "https://");
    if (url.indexOf("/indexlist/") >= 0) return url;
    var bookIdMatch = url.match(/\/(?:book|txt|indexlist)\/(\d+)/);
    if (bookIdMatch && bookIdMatch[1]) {
        return BASE_URL + "/indexlist/" + bookIdMatch[1] + "/";
    }
    return url;
}

function isValidIndexDoc(doc) {
    if (!doc) return false;
    var title = doc.select("title").text() + "";
    if (!title || title.indexOf("69書吧") === -1) return false;
    var listItems = doc.select("#catalog ul li");
    if (listItems.size() === 0) listItems = doc.select("li");
    return listItems.size() > 0;
}

function parseIndexPages(doc, indexUrl) {
    var pageList = [];
    var options = doc.select("#indexselect-top option, #indexselect option");
    for (var i = 0; i < options.size(); i++) {
        var e = options.get(i);
        var value = e.attr("value") + "";
        if (value) {
            if (value.indexOf("/") === 0) value = BASE_URL + value;
            pageList.push(value);
        }
    }
    if (pageList.length === 0) pageList.push(indexUrl);
    return pageList;
}

function parseChapterList(doc, host) {
    var list = [];
    var listItems = doc.select("#catalog ul li");
    if (listItems.size() === 0) listItems = doc.select("li");

    var bookTitle = "";
    var titleElement = doc.select("ul.last9 li.title a.back").first();
    if (!titleElement) {
        var pageTitle = doc.select("title").text() + "";
        var titleMatch = pageTitle.match(/《(.*?)》/);
        if (titleMatch && titleMatch[1]) bookTitle = titleMatch[1];
    } else {
        var titleText = titleElement.text() + "";
        var backMatch = titleText.match(/《(.*?)》/);
        if (backMatch && backMatch[1]) bookTitle = backMatch[1];
    }

    for (var i = 0; i < listItems.size(); i++) {
        var li = listItems.get(i);
        var className = li.attr("class") + "";
        if (className && className.indexOf("title") !== -1) continue;

        var name = "";
        var link = "";
        var protectedItem = li.select(".protected-chapter-link").first();
        if (!protectedItem) protectedItem = li.select("[data-cid-url]").first();

        if (protectedItem) {
            link = protectedItem.attr("data-cid-url") + "";
            name = protectedItem.text() + "";
            if (!name) name = protectedItem.attr("data-title") + "";
        }

        if (!link || link.length === 0) {
            var a = li.select("a").first();
            if (a) {
                link = a.attr("href") + "";
                name = a.text() + "";
            }
        }

        if (link && link.length > 0) {
            if (link.indexOf("/") === 0) link = host + link;
            if (name) {
                if (bookTitle && name.indexOf(bookTitle) !== -1) {
                    name = name.replace(bookTitle, "").trim();
                }
                name = name.trim();
            } else {
                name = "Chapter " + (list.length + 1);
            }
            list.push({ name: name, url: link, host: host });
        }
    }
    return list;
}

// ============ TOC page cache (auto-check) ============
var _TOC_CACHE_PREFIX = "69sh_toc_";
var _UPDATE_TIME_PREFIX = "69sh_ut_";

function getTocCacheKey(indexUrl) {
    var m = (indexUrl || "").match(/\/indexlist\/(\d+)\/?(\d*)/);
    if (m) {
        return m[1] + "_p" + (m[2] || "1");
    }
    return (indexUrl || "").replace(/[^a-zA-Z0-9]/g, "_");
}

function getTocPageCache(indexUrl) {
    try {
        var raw = localStorage.getItem(_TOC_CACHE_PREFIX + getTocCacheKey(indexUrl));
        if (raw) return JSON.parse(raw);
    } catch (e) {}
    return null;
}

function setTocPageCache(indexUrl, chapters) {
    if (!chapters || chapters.length === 0) return;
    var cacheKey = getTocCacheKey(indexUrl);
    var bookId = cacheKey.split("_p")[0];
    var updateTime = "";
    try { updateTime = localStorage.getItem(_UPDATE_TIME_PREFIX + bookId) + ""; } catch (e) {}
    try {
        localStorage.setItem(_TOC_CACHE_PREFIX + cacheKey, JSON.stringify({
            chapters: chapters,
            updateTime: updateTime,
            ts: Date.now()
        }));
    } catch (e) {}
}

function invalidateTocCache(bookId) {
    if (!bookId) return;
    for (var p = 1; p <= 20; p++) {
        try { localStorage.removeItem(_TOC_CACHE_PREFIX + bookId + "_p" + p); } catch (e) {}
    }
}

function syncTocCacheValidity(bookId, updateTime) {
    if (!bookId || !updateTime) return;
    try {
        var key = _UPDATE_TIME_PREFIX + bookId;
        var prev = localStorage.getItem(key) + "";
        if (prev && prev !== updateTime) invalidateTocCache(bookId);
        localStorage.setItem(key, updateTime);
    } catch (e) {}
}

function getBookUpdateTime(bookId) {
    if (!bookId) return "";
    try {
        return localStorage.getItem(_UPDATE_TIME_PREFIX + bookId) + "";
    } catch (e) {}
    return "";
}

function markBookDetailSynced(bookId, updateTime) {
    if (!bookId) return;
    try { localStorage.setItem(_DETAIL_SYNC_PREFIX + bookId, String(Date.now())); } catch (e) {}
    if (updateTime) syncTocCacheValidity(bookId, updateTime);
}

function shouldSkipDetailRefresh(bookId) {
    if (!bookId) return false;
    var ut = getBookUpdateTime(bookId);
    if (!ut) return false;
    try {
        var ts = parseInt(localStorage.getItem(_DETAIL_SYNC_PREFIX + bookId) || "0", 10);
        return ts > 0 && (Date.now() - ts) < _DETAIL_SYNC_TTL_MS;
    } catch (e) {}
    return false;
}

function fetchBookUpdateTime(bookUrl) {
    bookUrl = (bookUrl || "").replace("http://", "https://");
    var doc = fetchCF(bookUrl);
    if (!doc) return "";
    var updateTime = doc.select('meta[property="og:novel:update_time"]').attr("content") + "";
    var bookIdMatch = bookUrl.match(/\/book\/(\d+)/);
    if (bookIdMatch && bookIdMatch[1] && updateTime) {
        markBookDetailSynced(bookIdMatch[1], updateTime);
    }
    return updateTime;
}

function ensureTocCacheFresh(bookUrl) {
    bookUrl = (bookUrl || "").replace("http://", "https://");
    var bookIdMatch = bookUrl.match(/\/book\/(\d+)/);
    if (!bookIdMatch || !bookIdMatch[1]) return;
    var bookId = bookIdMatch[1];
    if (shouldSkipDetailRefresh(bookId)) {
        Console.log("[69sh] ensureTocCacheFresh skip bookId=" + bookId);
        return;
    }
    var updateTime = fetchBookUpdateTime(bookUrl);
    if (updateTime) {
        syncTocCacheValidity(bookId, updateTime);
    }
}